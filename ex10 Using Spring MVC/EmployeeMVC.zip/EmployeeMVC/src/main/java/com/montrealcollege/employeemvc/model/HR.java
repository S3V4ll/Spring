
package com.montrealcollege.employeemvc.model;

import org.springframework.stereotype.Component;

@Component
public class HR implements IDepartment{
    private String name="HR";

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
}
