package com.montrealcollege.employeemvc.model;

public interface IDepartment {

    public String getName();

    public void setName(String name);

}
