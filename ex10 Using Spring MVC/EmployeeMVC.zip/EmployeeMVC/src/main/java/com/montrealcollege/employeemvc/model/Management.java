
package com.montrealcollege.employeemvc.model;

import org.springframework.stereotype.Component;

@Component
public class Management implements IDepartment{
    private String name="Management";

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
}
