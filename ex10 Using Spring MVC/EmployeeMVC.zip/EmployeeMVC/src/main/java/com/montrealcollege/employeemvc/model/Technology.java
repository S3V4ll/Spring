
package com.montrealcollege.employeemvc.model;

import org.springframework.stereotype.Component;

@Component
public class Technology implements IDepartment{
    private String name="Technology";

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
}
